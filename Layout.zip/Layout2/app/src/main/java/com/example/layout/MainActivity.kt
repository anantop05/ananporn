package com.example.layout

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupLayoutSwitchingButtons()
        setupChangeTextButton(R.layout.activity_main)
    }

    private fun setupLayoutSwitchingButtons() {
        findViewById<Button>(R.id.btnLinearLayout).setOnClickListener { loadLayout(R.layout.activity_main) }
        findViewById<Button>(R.id.btnRelativeLayout).setOnClickListener { loadLayout(R.layout.relative_layout) }
        findViewById<Button>(R.id.btnGridLayout).setOnClickListener { loadLayout(R.layout.grid_layout) }
        findViewById<Button>(R.id.btnFrameLayout).setOnClickListener { loadLayout(R.layout.frame_layout) }
        findViewById<Button>(R.id.btnConstraintLayout).setOnClickListener { loadLayout(R.layout.constraint_layout) }
    }

    private fun loadLayout(layoutResId: Int) {
        setContentView(layoutResId)
        setupChangeTextButton(layoutResId)
        if (layoutResId == R.layout.activity_main) {
            setupLayoutSwitchingButtons()
        }
    }

    private fun setupChangeTextButton(layoutResId: Int) {
        val textView = findViewById<TextView>(R.id.textView)
        val changeTextButton = findViewById<Button>(R.id.changeTextButton)

        changeTextButton.setOnClickListener {
            when (layoutResId) {
                R.layout.activity_main -> textView.text = "Hello from Linear Layout!"
                R.layout.relative_layout -> textView.text = "Hello from Relative Layout!"
                R.layout.grid_layout -> textView.text = "Hello from Grid Layout!"
                R.layout.frame_layout -> textView.text = "Hello from Frame Layout!"
                R.layout.constraint_layout -> textView.text = "Hello from Constraint Layout!"
                else -> textView.text = "Hello from Android!"
            }
        }
    }
}
